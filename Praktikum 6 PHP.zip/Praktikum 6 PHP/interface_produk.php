

<?php
interface Bentuk
{
    public function hitungLuas();
}
class Persegi implements Bentuk
{
    private $sisi;

    public function __construct($sisi)
    {
        $this->sisi = $sisi;
    }

    public function hitungLuas()
    {
        return $this->sisi * $this->sisi;
    }

    public function getInfo()
    {
        return "Luas Persegi (sisi=" . $this->sisi . "): " . $this->hitungLuas();
    }
}

class Lingkaran implements Bentuk
{
    private $radius;

    public function __construct($radius)
    {
        $this->radius = $radius;
    }

    public function hitungLuas()
    {
        return 3.14 * $this->radius * $this->radius;
    }

    public function getInfo()
    {
        return "Luas Lingkaran (radius=" . $this->radius . "): " . $this->hitungLuas();
    }
}

$bentukArray = [
    new Persegi(5),
    new Lingkaran(7)
];

foreach ($bentukArray as $bentuk) {
    echo $bentuk->getInfo() . "<br>";
}

?>