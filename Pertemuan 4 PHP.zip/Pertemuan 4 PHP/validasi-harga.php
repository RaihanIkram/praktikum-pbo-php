<?php

class Product
{
    private $nama;
    private $harga;
    private $kategori;
    private $diskon;

    // Constructor
    public function __construct($nama, $harga, $kategori)
    {
        $this->nama = $nama;
        $this->setHarga($harga);
        $this->kategori = $kategori;
        $this->diskon = 0;
    }
    // Setter Harga dengan validasi
    public function setHarga($harga)
    {
        if (!is_numeric($harga)) {
            throw new Exception("Harga harus berupa angka!");
        }

        if ($harga < 0) {
            throw new Exception("Harga tidak boleh negatif!");
        }

        if ($harga > 100000000) {
            throw new Exception("Harga maksimal Rp 100.000.000!");
        }

        $this->harga = $harga;
    }
    
    // Getter Harga
    public function getHarga()
    {
        return $this->harga;
    }

    // Getter Nama
    public function getNama()
    {
        return $this->nama;
    }

    // Getter Kategori
    public function getKategori()
    {
        return $this->kategori;
    }

    // Setter Diskon dengan validasi
    public function setDiskon($diskon)
    {
        if ($diskon < 0 || $diskon > 100) {
            throw new Exception("Diskon harus antara 0-100%!");
        }

        $this->diskon = $diskon;
    }
    // Getter Diskon
    public function getDiskon()
    {
        return $this->diskon;
    }

    // Menghitung harga setelah diskon
    public function getHargaSetelahDiskon()
    {
        return $this->harga * (1 - $this->diskon / 100);
    }

    // Menampilkan informasi produk
    public function getInfo()
    {
        return "Produk: " . $this->nama . "<br>" .
               "Kategori: " . $this->kategori . "<br>" .
               "Harga: Rp " . number_format($this->harga, 0, ',', '.') . "<br>" .
               "Diskon: " . $this->diskon . "%<br>" .
               "Harga Setelah Diskon: Rp " .
               number_format($this->getHargaSetelahDiskon(), 0, ',', '.');
    }
}

try {

    $product = new Product(
        "Laptop Gaming",
        25000000,
        "Elektronik"
    );

    echo $product->getInfo();
    echo "<br><br>";

    // Mengubah diskon
    $product->setDiskon(15);

    echo $product->getInfo();

} catch (Exception $e) {

    echo "Error: " . $e->getMessage();

}

?>