<?php
class Mobil
{
    // Property
    private $merk;
    private $warna;
    private $kecepatan;

    // Getter Merk
    public function getMerk()
    {
        return $this->merk;
    }
    
    // Getter Warna
    public function getWarna()
    {
        return $this->warna;
    }

    // Getter Kecepatan
    public function getKecepatan()
    {
        return $this->kecepatan;
    }

    // Setter Merk
    public function setMerk($merk)
    {
        $this->merk = $merk;
    }

    // Setter Warna dengan validasi
    public function setWarna($warna)
    {
        if (empty($warna)) {
            throw new Exception("Warna tidak boleh kosong!");
        }

        if (strlen($warna) < 3) {
            throw new Exception("Warna minimal 3 karakter!");
        }

        $this->warna = $warna;
    }

    // Setter Kecepatan dengan validasi
    public function setKecepatan($kecepatan)
    {
        if ($kecepatan < 0) {
            throw new Exception("Kecepatan tidak boleh negatif!");
        }

        if ($kecepatan > 200) {
            throw new Exception("Kecepatan maksimal 200 km/jam!");
        }

        $this->kecepatan = $kecepatan;
    }

    // Method infoMobil
    public function infoMobil()
    {
        return "Mobil " . $this->merk .
               " berwarna " . $this->warna .
               " dengan kecepatan " . $this->kecepatan . " km/jam";
    }
}

// Object
try {
    $mobil = new Mobil();

    $mobil->setMerk("Toyota");
    $mobil->setWarna("Merah");
    $mobil->setKecepatan(80);

    echo $mobil->infoMobil();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>