<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Menampilkan seluruh data produk
Route::get('/products', [ProductController::class, 'index']);

// Menambahkan data produk
Route::post('/products', [ProductController::class, 'store']);

// Menampilkan produk berdasarkan ID
Route::get('/products/{id}', [ProductController::class, 'show']);

// Memperbarui data produk
Route::put('/products/{id}', [ProductController::class, 'update']);

// Menghapus data produk
Route::delete('/products/{id}', [ProductController::class, 'destroy']);
