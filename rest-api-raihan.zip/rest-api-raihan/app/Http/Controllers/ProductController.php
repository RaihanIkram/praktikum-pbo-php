<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    // Menampilkan seluruh data produk
    public function index()
    {
        $products = Product::all();

        return response()->json($products);
    }

    // Menambahkan data produk baru
    public function store(Request $request)
    {
        $product = Product::create($request->all());

        return response()->json($product, 201);
    }

    // Menampilkan data produk berdasarkan ID
    public function show(string $id)
    {
        $product = Product::find($id);

        return response()->json($product);
    }

    // Memperbarui data produk berdasarkan ID
    public function update(Request $request, string $id)
    {
        $product = Product::find($id);

        $product->update($request->all());

        return response()->json($product);
    }

    // Menghapus data produk berdasarkan ID
    public function destroy(string $id)
    {
        $product = Product::find($id);

        $product->delete();

        return response()->json([
            'message' => 'Product berhasil dihapus'
        ]);
    }
}
