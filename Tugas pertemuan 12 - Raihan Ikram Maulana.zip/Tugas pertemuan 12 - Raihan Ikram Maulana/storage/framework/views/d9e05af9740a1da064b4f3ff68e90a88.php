<!DOCTYPE html>
<html>
<head>
    <title>Praktikum Laravel</title>
</head>
<body>
    <h1>Data Mahasiswa</h1>

    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
            <?php echo e($mhs->nama); ?> - <?php echo e($mhs->nim); ?>

        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\laragon\www\Tugas\resources\views/hello.blade.php ENDPATH**/ ?>