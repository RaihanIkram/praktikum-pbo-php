<?php

require_once __DIR__ . '/Product.php';

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Menentukan ID berdasarkan request
$idSource = $_SERVER['REQUEST_METHOD'] === 'POST'
    ? ($_POST['id'] ?? '')
    : ($_GET['id'] ?? '');

$id = filter_var($idSource, FILTER_VALIDATE_INT);

if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit('ID produk tidak valid.');
}

// Mengambil data produk
$productData = Product::findById($id);

if (!$productData) {
    http_response_code(404);
    exit('Produk tidak ditemukan. Silakan kembali ke halaman utama.');
}

$error = '';

$old = [
    'nama' => $productData['nama'],
    'deskripsi' => $productData['deskripsi'],
    'harga' => $productData['harga'],
    'stok' => $productData['stok']
];

// Memproses perubahan produk
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['nama'] = trim($_POST['nama'] ?? '');
    $old['deskripsi'] = trim($_POST['deskripsi'] ?? '');
    $old['harga'] = trim($_POST['harga'] ?? '');
    $old['stok'] = trim($_POST['stok'] ?? '');

    if ($old['nama'] === '') {
        $error = 'Nama produk wajib diisi.';
    } elseif ($old['deskripsi'] === '') {
        $error = 'Deskripsi produk wajib diisi.';
    } elseif (
        !is_numeric($old['harga']) ||
        (float) $old['harga'] < 0
    ) {
        $error = 'Harga harus berupa angka dan tidak boleh negatif.';
    } elseif (
        filter_var($old['stok'], FILTER_VALIDATE_INT) === false ||
        (int) $old['stok'] < 0
    ) {
        $error = 'Stok harus berupa bilangan bulat dan tidak boleh negatif.';
    } else {
        $product = new Product();

        $hasil = $product
            ->setNama($old['nama'])
            ->setDeskripsi($old['deskripsi'])
            ->setHarga((float) $old['harga'])
            ->setStok((int) $old['stok'])
            ->update($id);

        if ($hasil) {
            header('Location: index.php?status=updated');
            exit;
        }

        $error = 'Produk gagal diperbarui.';
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Produk</title>

    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="container">

    <header class="page-header">
        <h1>Edit Produk</h1>
        <p class="subtitle">
            Perbarui informasi produk sesuai kebutuhan.
        </p>
    </header>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <section class="card">
        <form method="POST" action="edit.php?id=<?= e($id) ?>">

            <input
                type="hidden"
                name="id"
                value="<?= e($id) ?>"
            >

            <div class="form-grid">

                <div class="field full">
                    <label for="nama">Nama Produk</label>
                    <input
                        type="text"
                        id="nama"
                        name="nama"
                        maxlength="150"
                        value="<?= e($old['nama']) ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea
                        id="deskripsi"
                        name="deskripsi"
                        required
                    ><?= e($old['deskripsi']) ?></textarea>
                </div>

                <div class="field">
                    <label for="harga">Harga (Rp)</label>
                    <input
                        type="number"
                        id="harga"
                        name="harga"
                        min="0"
                        step="0.01"
                        value="<?= e($old['harga']) ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="stok">Stok</label>
                    <input
                        type="number"
                        id="stok"
                        name="stok"
                        min="0"
                        step="1"
                        value="<?= e($old['stok']) ?>"
                        required
                    >
                </div>

                <div class="field full actions">
                    <button type="submit">
                        Simpan Perubahan
                    </button>

                    <a class="button edit" href="index.php">
                        Batal
                    </a>
                </div>

            </div>
        </form>
    </section>

</div>
</body>
</html>
