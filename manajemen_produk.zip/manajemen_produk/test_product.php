<?php

require_once 'Product.php';

echo "=== PENGUJIAN PRODUCT ===" . PHP_EOL;

// 1. CREATE: Tambah produk
$product = new Product();

$hasil = $product
    ->setNama("Mouse Wireless Test")
    ->setDeskripsi("Produk untuk pengujian CRUD")
    ->setHarga(150000)
    ->setStok(10)
    ->save();

if (!$hasil) {
    exit("Gagal menambahkan produk." . PHP_EOL);
}

echo "[OK] CREATE: Produk berhasil ditambahkan." . PHP_EOL;

// 2. READ ALL: Ambil seluruh produk
$dataProduk = Product::findAll();

echo "[OK] READ ALL: Ditemukan "
    . count($dataProduk)
    . " produk." . PHP_EOL;

// Ambil produk terbaru untuk pengujian berikutnya
$produkTerbaru = $dataProduk[0] ?? null;

if (!$produkTerbaru) {
    exit("Produk tidak ditemukan untuk pengujian." . PHP_EOL);
}

$id = (int) $produkTerbaru['id'];

echo "ID produk pengujian: {$id}" . PHP_EOL;

// 3. READ: Ambil produk berdasarkan ID
$detail = Product::findById($id);

if ($detail) {
    echo "[OK] READ: "
        . $detail['nama']
        . PHP_EOL;
} else {
    exit("Gagal membaca produk berdasarkan ID." . PHP_EOL);
}

// 4. UPDATE: Ubah data produk
$produkUpdate = new Product();

$produkUpdate
    ->setNama("Mouse Wireless Test Updated")
    ->setDeskripsi("Data produk sudah diperbarui")
    ->setHarga(175000)
    ->setStok(15);

if (!$produkUpdate->update($id)) {
    exit("Gagal memperbarui produk." . PHP_EOL);
}

$hasilUpdate = Product::findById($id);

if (
    $hasilUpdate &&
    $hasilUpdate['nama'] === "Mouse Wireless Test Updated"
) {
    echo "[OK] UPDATE: Produk berhasil diperbarui." . PHP_EOL;
} else {
    exit("Hasil UPDATE tidak sesuai." . PHP_EOL);
}

// 5. DELETE: Hapus produk pengujian
if (!Product::delete($id)) {
    exit("Gagal menghapus produk pengujian." . PHP_EOL);
}

$hasilHapus = Product::findById($id);

if (!$hasilHapus) {
    echo "[OK] DELETE: Produk berhasil dihapus." . PHP_EOL;
} else {
    exit("Produk masih ditemukan setelah penghapusan." . PHP_EOL);
}

echo "=== SEMUA PENGUJIAN SELESAI ===" . PHP_EOL;
