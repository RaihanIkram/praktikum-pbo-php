<?php

require_once 'DatabaseConnection.php';

class Product
{
    private $id;
    private $nama;
    private $deskripsi;
    private $harga;
    private $stok;
    private $db;

    public function __construct()
    {
        $this->db = DatabaseConnection::getInstance()
            ->getConnection();
    }

    public function setNama($nama)
    {
        $this->nama = $nama;
        return $this;
    }

    public function setDeskripsi($deskripsi)
    {
        $this->deskripsi = $deskripsi;
        return $this;
    }

    public function setHarga($harga)
    {
        $this->harga = $harga;
        return $this;
    }

    public function setStok($stok)
    {
        $this->stok = $stok;
        return $this;
    }

    // CREATE: Menyimpan produk baru
    public function save()
    {
        $sql = "INSERT INTO products
                (nama, deskripsi, harga, stok)
                VALUES
                (:nama, :deskripsi, :harga, :stok)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            'nama' => $this->nama,
            'deskripsi' => $this->deskripsi,
            'harga' => $this->harga,
            'stok' => $this->stok
        ]);
    }

    // READ ALL: Mengambil semua produk
    public static function findAll()
    {
        $db = DatabaseConnection::getInstance()
            ->getConnection();

        $sql = "SELECT * FROM products ORDER BY id DESC";

        $stmt = $db->query($sql);

        return $stmt->fetchAll();
    }

    // READ: Mengambil satu produk berdasarkan ID
    public static function findById($id)
    {
        $db = DatabaseConnection::getInstance()
            ->getConnection();

        $sql = "SELECT * FROM products WHERE id = :id";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            'id' => $id
        ]);

        return $stmt->fetch();
    }

    // UPDATE: Memperbarui produk berdasarkan ID
    public function update($id)
    {
        $sql = "UPDATE products
                SET nama = :nama,
                    deskripsi = :deskripsi,
                    harga = :harga,
                    stok = :stok
                WHERE id = :id";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            'nama' => $this->nama,
            'deskripsi' => $this->deskripsi,
            'harga' => $this->harga,
            'stok' => $this->stok,
            'id' => $id
        ]);
    }

    // DELETE: Menghapus produk berdasarkan ID
    public static function delete($id)
    {
        $db = DatabaseConnection::getInstance()
            ->getConnection();

        $sql = "DELETE FROM products WHERE id = :id";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            'id' => $id
        ]);

        return $stmt->rowCount() > 0;
    }
}
