<?php

require_once __DIR__ . '/Product.php';

// Penghapusan hanya diperbolehkan menggunakan POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Metode request tidak diizinkan.');
}

// Validasi ID produk
$id = filter_var(
    $_POST['id'] ?? '',
    FILTER_VALIDATE_INT
);

if ($id === false || $id === null || $id < 1) {
    header('Location: index.php?status=notfound');
    exit;
}

// Pastikan produk tersedia
$product = Product::findById($id);

if (!$product) {
    header('Location: index.php?status=notfound');
    exit;
}

// Hapus produk dari database
$hasil = Product::delete($id);

if ($hasil) {
    header('Location: index.php?status=deleted');
    exit;
}

header('Location: index.php?status=delete_failed');
exit;
