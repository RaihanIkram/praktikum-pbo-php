<?php

require_once __DIR__ . '/Product.php';

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$error = '';

$old = [
    'nama' => '',
    'deskripsi' => '',
    'harga' => '',
    'stok' => ''
];

// Memproses form tambah produk
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['nama'] = trim($_POST['nama'] ?? '');
    $old['deskripsi'] = trim($_POST['deskripsi'] ?? '');
    $old['harga'] = trim($_POST['harga'] ?? '');
    $old['stok'] = trim($_POST['stok'] ?? '');

    if ($old['nama'] === '') {
        $error = 'Nama produk wajib diisi.';
    } elseif ($old['deskripsi'] === '') {
        $error = 'Deskripsi produk wajib diisi.';
    } elseif (
        !is_numeric($old['harga']) ||
        (float) $old['harga'] < 0
    ) {
        $error = 'Harga harus berupa angka dan tidak boleh negatif.';
    } elseif (
        filter_var($old['stok'], FILTER_VALIDATE_INT) === false ||
        (int) $old['stok'] < 0
    ) {
        $error = 'Stok harus berupa bilangan bulat dan tidak boleh negatif.';
    } else {
        $product = new Product();

        $hasil = $product
            ->setNama($old['nama'])
            ->setDeskripsi($old['deskripsi'])
            ->setHarga((float) $old['harga'])
            ->setStok((int) $old['stok'])
            ->save();

        if ($hasil) {
            header('Location: index.php?status=created');
            exit;
        }

        $error = 'Produk gagal disimpan.';
    }
}

// Mengambil seluruh produk
$products = Product::findAll();

// Pesan status
$statusMessages = [
    'created' => 'Produk berhasil ditambahkan.',
    'updated' => 'Produk berhasil diperbarui.',
    'deleted' => 'Produk berhasil dihapus.',
    'notfound' => 'Produk tidak ditemukan.',
    'delete_failed' => 'Produk gagal dihapus.'
];

$status = $_GET['status'] ?? '';
$notice = $statusMessages[$status] ?? '';

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manajemen Produk</title>

    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>

<body>
<div class="container">

    <header class="page-header">
        <h1>Manajemen Produk</h1>
        <p class="subtitle">
            Kelola inventaris produk menggunakan PHP, PDO, dan MySQL.
        </p>
    </header>

    <?php if ($notice !== ''): ?>
        <div class="notice">
            <?= e($notice) ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <section class="card">
        <h2>Tambah Produk</h2>

        <form method="POST" action="index.php">
            <div class="form-grid">

                <div class="field full">
                    <label for="nama">Nama Produk</label>
                    <input
                        type="text"
                        id="nama"
                        name="nama"
                        maxlength="150"
                        value="<?= e($old['nama']) ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea
                        id="deskripsi"
                        name="deskripsi"
                        required
                    ><?= e($old['deskripsi']) ?></textarea>
                </div>

                <div class="field">
                    <label for="harga">Harga (Rp)</label>
                    <input
                        type="number"
                        id="harga"
                        name="harga"
                        min="0"
                        step="0.01"
                        value="<?= e($old['harga']) ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="stok">Stok</label>
                    <input
                        type="number"
                        id="stok"
                        name="stok"
                        min="0"
                        step="1"
                        value="<?= e($old['stok']) ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <button type="submit">Simpan Produk</button>
                </div>

            </div>
        </form>
    </section>

    <section class="card">
        <div class="section-heading">
            <h2>Daftar Produk</h2>
            <span class="product-count">
                Total: <?= count($products) ?> produk
            </span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Produk</th>
                        <th>Deskripsi</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="6" class="empty">
                            Belum ada produk. Tambahkan melalui form di atas.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= e($product['id']) ?></td>
                            <td><?= e($product['nama']) ?></td>
                            <td><?= e($product['deskripsi']) ?></td>

                            <td>
                                Rp <?= number_format(
                                    (float) $product['harga'],
                                    2,
                                    ',',
                                    '.'
                                ) ?>
                            </td>

                            <td><?= e($product['stok']) ?></td>

                            <td>
                                <div class="actions">
                                    <a
                                        class="button edit"
                                        href="edit.php?id=<?= e($product['id']) ?>"
                                    >
                                        Edit
                                    </a>

                                    <form
                                        class="delete-form"
                                        method="POST"
                                        action="delete.php"
                                    >
                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= e($product['id']) ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="button delete"
                                        >
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
</body>
</html>
