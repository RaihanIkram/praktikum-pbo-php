document.addEventListener("DOMContentLoaded", function () {
    const deleteForms = document.querySelectorAll(".delete-form");

    deleteForms.forEach(function (form) {
        form.addEventListener("submit", function (event) {
            const row = form.closest("tr");

            const nameCell = row
                ? row.querySelector("td:nth-child(2)")
                : null;

            const productName = nameCell
                ? nameCell.textContent.trim()
                : "produk ini";

            const confirmed = window.confirm(
                `Yakin ingin menghapus "${productName}"?`
            );

            if (!confirmed) {
                event.preventDefault();
            }
        });
    });
});
