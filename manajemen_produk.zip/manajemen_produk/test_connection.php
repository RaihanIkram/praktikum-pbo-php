<?php

require_once 'DatabaseConnection.php';

$db = DatabaseConnection::getInstance()->getConnection();

echo "Berhasil terkoneksi ke database materi_pdo!"
    . PHP_EOL;

$version = $db->query('SELECT VERSION()')->fetchColumn();

echo "Versi MySQL: " . $version . PHP_EOL;
