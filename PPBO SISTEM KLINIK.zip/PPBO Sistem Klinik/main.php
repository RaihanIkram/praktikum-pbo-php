<?php

declare(strict_types=1);

require_once __DIR__ . '/autoload.php';

use Klinik\Domain\Dokter;
use Klinik\Domain\Pasien;

// Membuat objek berdasarkan tiga class pada Class Diagram.
$pasien = new Pasien(
    1001,
    'Andi Saputra',
    'Pontianak',
    6281234567890
);

$dokter = new Dokter(
    201,
    'dr. Maya Putri',
    'Dokter Umum'
);

// Pasien melakukan dua kali pemeriksaan dengan dokter yang sama.
$pemeriksaanPertama = $pasien->melakukanPemeriksaan(
    $dokter,
    5001,
    new DateTimeImmutable('2026-10-30'),
    'Demam dan sakit kepala'
);

$dokter->isiHasilPemeriksaan(
    $pemeriksaanPertama,
    'Pasien disarankan beristirahat dan menjaga asupan cairan.'
);

$pemeriksaanKedua = $pasien->melakukanPemeriksaan(
    $dokter,
    5002,
    new DateTimeImmutable('2026-10-31'),
    'Kontrol lanjutan, demam sudah berkurang'
);

$dokter->isiHasilPemeriksaan(
    $pemeriksaanKedua,
    'Kondisi pasien membaik. Lanjutkan istirahat dan kontrol bila keluhan muncul kembali.'
);

// Menunjukkan method ubahDataPasien dan ubahSpesialisasi.
$pasien->ubahDataPasien(alamat: 'Sungai Jawi, Pontianak');
$dokter->ubahSpesialisasi('Dokter Umum');

// Mengambil data riwayat pemeriksaan.
$riwayatPemeriksaan = $pasien->lihatRiwayatPemeriksaan();
$totalPemeriksaanPasien = count($riwayatPemeriksaan);
$totalPemeriksaanDokter = count($dokter->getPemeriksaanDitangani());

// ======================================================
// OUTPUT TERMINAL
// ======================================================

ob_start();

echo "SIMULASI SISTEM KLINIK - PHP OOP\n";
echo "================================\n";
echo $pasien->mendaftar() . "\n";
echo 'Dokter yang bertugas: ' . $dokter->getNama() . ' (' . $dokter->getSpesialisasi() . ")\n\n";

echo "DATA PASIEN\n";
echo 'ID Pasien : ' . $pasien->getIdPasien() . "\n";
echo 'Nama      : ' . $pasien->getNama() . "\n";
echo 'Alamat    : ' . $pasien->getAlamat() . "\n";
echo 'No. Telp  : ' . $pasien->getNoTelepon() . "\n\n";

echo "RIWAYAT PEMERIKSAAN PASIEN\n";

foreach ($riwayatPemeriksaan as $pemeriksaan) {
    echo $pemeriksaan->tampilkanDetail() . "\n";
}

echo "----------------------------------------\n";
echo 'Total pemeriksaan pasien : ' . $totalPemeriksaanPasien . "\n";
echo 'Total pemeriksaan dokter : ' . $totalPemeriksaanDokter . "\n";

$terminalOutput = ob_get_clean();

// Jika dijalankan melalui terminal, tampilkan output teks.
if (PHP_SAPI === 'cli') {
    echo $terminalOutput;
    exit;
}

// ======================================================
// FUNGSI ESCAPE UNTUK HTML
// ======================================================

$escape = static function ($value): string {
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
};

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sistem Klinik | Dashboard</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f3f6fb;
            color: #243247;
            line-height: 1.6;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 35px 22px;
        }

        /* HEADER */

        .header {
            background: linear-gradient(135deg, #173b63, #2563a5);
            color: white;
            padding: 30px;
            border-radius: 14px;
            margin-bottom: 28px;
            box-shadow: 0 5px 18px rgba(20, 55, 90, 0.12);
        }

        .header h1 {
            font-size: 27px;
            margin-bottom: 5px;
        }

        .header p {
            color: #d8e7f7;
            font-size: 14px;
        }

        .header-label {
            display: inline-block;
            background: rgba(255, 255, 255, 0.15);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            margin-bottom: 12px;
        }

        /* STATISTIK */

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }

        .stat-card {
            background: white;
            padding: 22px;
            border-radius: 12px;
            border: 1px solid #e5ebf2;
            box-shadow: 0 3px 12px rgba(30, 55, 90, 0.04);
        }

        .stat-card span {
            display: block;
            color: #718096;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .stat-card h2 {
            font-size: 30px;
            color: #1e4978;
        }

        /* SECTION */

        .section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 24px;
            border: 1px solid #e5ebf2;
            box-shadow: 0 3px 12px rgba(30, 55, 90, 0.04);
        }

        .section-title {
            font-size: 19px;
            color: #234b76;
            padding-bottom: 14px;
            border-bottom: 1px solid #edf0f5;
            margin-bottom: 20px;
        }

        /* INFORMASI */

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .info-item {
            padding: 14px;
            background: #f7f9fc;
            border-radius: 9px;
        }

        .info-item span {
            display: block;
            font-size: 12px;
            color: #78869a;
            margin-bottom: 4px;
        }

        .info-item strong {
            font-size: 15px;
            color: #293b52;
            overflow-wrap: anywhere;
        }

        /* DOKTER */

        .doctor-card {
            background: #edf5ff;
            border-left: 4px solid #3277bb;
            border-radius: 9px;
            padding: 18px;
        }

        .doctor-card h3 {
            color: #214e7c;
            font-size: 18px;
        }

        .doctor-card p {
            color: #657b95;
            font-size: 14px;
            margin-top: 4px;
        }

        /* PEMERIKSAAN */

        .examination-list {
            display: grid;
            gap: 18px;
        }

        .examination-card {
            border: 1px solid #e5ebf2;
            border-radius: 10px;
            overflow: hidden;
        }

        .examination-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            padding: 15px 18px;
            background: #f7f9fc;
            border-bottom: 1px solid #e5ebf2;
        }

        .examination-header h3 {
            color: #284e77;
            font-size: 15px;
        }

        .status {
            background: #e0f4e9;
            color: #21804e;
            padding: 5px 11px;
            font-size: 11px;
            font-weight: bold;
            border-radius: 20px;
        }

        .examination-body {
            padding: 18px;
        }

        .examination-body pre {
            font-family: Arial, Helvetica, sans-serif;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
            font-size: 13px;
            line-height: 1.9;
            color: #4a5c72;
        }

        /* FOOTER */

        .footer {
            text-align: center;
            color: #8693a5;
            font-size: 12px;
            padding: 15px 0;
        }

        /* RESPONSIVE */

        @media (max-width: 650px) {
            .container {
                padding: 20px 14px;
            }

            .stats {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .header h1 {
                font-size: 22px;
            }

            .section {
                padding: 18px;
            }
        }
    </style>

</head>

<body>

    <div class="container">

        <!-- HEADER -->

        <header class="header">

            <div class="header-label">
                SISTEM INFORMASI KLINIK
            </div>

            <h1>Dashboard Sistem Klinik</h1>

            <p>
                Sistem pengelolaan data pasien dan riwayat pemeriksaan
                berbasis PHP Object-Oriented Programming.
            </p>

        </header>


        <!-- STATISTIK -->

        <div class="stats">

            <div class="stat-card">
                <span>Total Pasien</span>
                <h2>1</h2>
            </div>

            <div class="stat-card">
                <span>Dokter Terdaftar</span>
                <h2>1</h2>
            </div>

            <div class="stat-card">
                <span>Total Pemeriksaan</span>
                <h2><?= $totalPemeriksaanPasien ?></h2>
            </div>

        </div>


        <!-- DATA PASIEN -->

        <section class="section">

            <h2 class="section-title">Informasi Pasien</h2>

            <div class="info-grid">

                <div class="info-item">
                    <span>ID Pasien</span>
                    <strong><?= $escape($pasien->getIdPasien()) ?></strong>
                </div>

                <div class="info-item">
                    <span>Nama Pasien</span>
                    <strong><?= $escape($pasien->getNama()) ?></strong>
                </div>

                <div class="info-item">
                    <span>Alamat</span>
                    <strong><?= $escape($pasien->getAlamat()) ?></strong>
                </div>

                <div class="info-item">
                    <span>Nomor Telepon</span>
                    <strong><?= $escape($pasien->getNoTelepon()) ?></strong>
                </div>

            </div>

        </section>


        <!-- DATA DOKTER -->

        <section class="section">

            <h2 class="section-title">Dokter yang Menangani</h2>

            <div class="doctor-card">

                <h3><?= $escape($dokter->getNama()) ?></h3>

                <p>
                    ID Dokter:
                    <?= $escape($dokter->getIdDokter()) ?>
                    |
                    Spesialisasi:
                    <?= $escape($dokter->getSpesialisasi()) ?>
                </p>

            </div>

        </section>


        <!-- RIWAYAT PEMERIKSAAN -->

        <section class="section">

            <h2 class="section-title">
                Riwayat Pemeriksaan Pasien
            </h2>

            <div class="examination-list">

                <?php foreach ($riwayatPemeriksaan as $index => $pemeriksaan): ?>

                    <div class="examination-card">

                        <div class="examination-header">

                            <h3>
                                Pemeriksaan #<?= $index + 1 ?>
                            </h3>

                            <span class="status">
                                Tercatat
                            </span>

                        </div>

                        <div class="examination-body">

                            <pre><?= $escape($pemeriksaan->tampilkanDetail()) ?></pre>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        </section>


        <!-- RINGKASAN -->

        <section class="section">

            <h2 class="section-title">Ringkasan Aktivitas</h2>

            <div class="info-grid">

                <div class="info-item">
                    <span>Total Pemeriksaan Pasien</span>
                    <strong><?= $totalPemeriksaanPasien ?> Pemeriksaan</strong>
                </div>

                <div class="info-item">
                    <span>Total Pemeriksaan Dokter</span>
                    <strong><?= $totalPemeriksaanDokter ?> Pemeriksaan</strong>
                </div>

            </div>

        </section>


        <!-- FOOTER -->

        <footer class="footer">

            <p>
                Sistem Klinik | Implementasi PHP OOP dan SOLID Principle
            </p>

            <p>
                Praktikum Pemrograman Berorientasi Objek - 2026
            </p>

        </footer>

    </div>

</body>
</html>
