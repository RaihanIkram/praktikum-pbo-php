<?php

declare(strict_types=1);

namespace Klinik\Contracts;

/**
 * Kontrak minimum identitas pasien yang dibutuhkan oleh Pemeriksaan.
 * Interface ini hanya menyediakan satu fungsi yang benar-benar diperlukan.
 */
interface IdentitasPasienInterface
{
    public function getIdPasien(): int;
}
