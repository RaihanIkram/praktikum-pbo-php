<?php

declare(strict_types=1);

namespace Klinik\Contracts;

/**
 * Kontrak minimum identitas dokter yang dibutuhkan oleh Pemeriksaan.
 */
interface IdentitasDokterInterface
{
    public function getIdDokter(): int;
}
