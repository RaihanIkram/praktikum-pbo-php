<?php

declare(strict_types=1);

namespace Klinik\Domain;

use DateTimeImmutable;
use DomainException;
use InvalidArgumentException;
use Klinik\Contracts\IdentitasDokterInterface;
use Klinik\Contracts\IdentitasPasienInterface;

/** Class Dokter merepresentasikan identitas dokter dan tindakan pemeriksaannya. */
class Dokter implements IdentitasDokterInterface
{
    /** @var array<int, Pemeriksaan> Koleksi relasi Dokter ke Pemeriksaan. */
    private array $pemeriksaanDitangani = [];

    public function __construct(
        private int $idDokter,
        private string $nama,
        private string $spesialisasi
    ) {
        $this->validasiData();
    }

    /**
     * Membuat catatan pemeriksaan untuk pasien yang ditangani dokter ini.
     * Parameter pasien menggunakan interface, bukan bergantung pada implementasi konkret.
     */
    public function memeriksaPasien(
        IdentitasPasienInterface $pasien,
        int $idPemeriksaan,
        DateTimeImmutable $tanggalPemeriksaan,
        string $keluhan
    ): Pemeriksaan {
        if (isset($this->pemeriksaanDitangani[$idPemeriksaan])) {
            throw new InvalidArgumentException('ID pemeriksaan sudah tercatat pada daftar dokter ini.');
        }

        $pemeriksaan = Pemeriksaan::buatPemeriksaan(
            $idPemeriksaan,
            $this,
            $pasien,
            $tanggalPemeriksaan,
            $keluhan
        );

        $this->pemeriksaanDitangani[$pemeriksaan->getIdPemeriksaan()] = $pemeriksaan;

        return $pemeriksaan;
    }

    /** Dokter hanya boleh mengisi hasil untuk pemeriksaan yang ditanganinya. */
    public function isiHasilPemeriksaan(Pemeriksaan $pemeriksaan, string $hasil): void
    {
        $idPemeriksaan = $pemeriksaan->getIdPemeriksaan();
        $terdaftarPadaDokterIni = isset($this->pemeriksaanDitangani[$idPemeriksaan])
            && $this->pemeriksaanDitangani[$idPemeriksaan] === $pemeriksaan;

        if ($pemeriksaan->getIdDokter() !== $this->idDokter || !$terdaftarPadaDokterIni) {
            throw new DomainException('Dokter ini tidak tercatat sebagai penanggung jawab pemeriksaan tersebut.');
        }

        $pemeriksaan->catatHasil($hasil);
    }

    public function ubahSpesialisasi(string $spesialisasi): void
    {
        $spesialisasi = trim($spesialisasi);
        if ($spesialisasi === '') {
            throw new InvalidArgumentException('Spesialisasi dokter tidak boleh kosong.');
        }

        $this->spesialisasi = $spesialisasi;
    }

    // Getter digunakan untuk membaca atribut private secara terkendali.
    public function getIdDokter(): int
    {
        return $this->idDokter;
    }

    public function getNama(): string
    {
        return $this->nama;
    }

    public function getSpesialisasi(): string
    {
        return $this->spesialisasi;
    }

    /** Mengembalikan pemeriksaan yang ditangani dokter (relasi 1 ke 0..*). */
    public function getPemeriksaanDitangani(): array
    {
        return array_values($this->pemeriksaanDitangani);
    }

    private function validasiData(): void
    {
        if ($this->idDokter <= 0) {
            throw new InvalidArgumentException('ID dokter harus lebih besar dari nol.');
        }
        if (trim($this->nama) === '') {
            throw new InvalidArgumentException('Nama dokter wajib diisi.');
        }
        if (trim($this->spesialisasi) === '') {
            throw new InvalidArgumentException('Spesialisasi dokter wajib diisi.');
        }

        $this->nama = trim($this->nama);
        $this->spesialisasi = trim($this->spesialisasi);
    }
}
