<?php

declare(strict_types=1);

namespace Klinik\Domain;

use DateTimeImmutable;
use InvalidArgumentException;
use Klinik\Contracts\IdentitasPasienInterface;

/**
 * Class Pasien merepresentasikan identitas pasien dan riwayat pemeriksaannya.
 * Atribut inti mengikuti Class Diagram; koleksi riwayat adalah implementasi
 * relasi satu Pasien dengan nol atau banyak Pemeriksaan.
 */
class Pasien implements IdentitasPasienInterface
{
    /** @var array<int, Pemeriksaan> Koleksi relasi Pasien ke Pemeriksaan. */
    private array $riwayatPemeriksaan = [];

    public function __construct(
        private int $idPasien,
        private string $nama,
        private string $alamat,
        private int $noTelepon
    ) {
        $this->validasiData();
    }

    /** Mewakili proses pendaftaran pasien pada simulasi tanpa database. */
    public function mendaftar(): string
    {
        return "Pasien {$this->nama} berhasil didaftarkan dengan ID {$this->idPasien}.";
    }

    /** Memperbarui satu atau beberapa data pasien yang diberikan. */
    public function ubahDataPasien(
        ?string $nama = null,
        ?string $alamat = null,
        ?int $noTelepon = null
    ): void {
        if ($nama === null && $alamat === null && $noTelepon === null) {
            throw new InvalidArgumentException('Minimal satu data pasien harus diberikan untuk diubah.');
        }

        if ($nama !== null) {
            $nama = trim($nama);
            if ($nama === '') {
                throw new InvalidArgumentException('Nama pasien tidak boleh kosong.');
            }
            $this->nama = $nama;
        }

        if ($alamat !== null) {
            $alamat = trim($alamat);
            if ($alamat === '') {
                throw new InvalidArgumentException('Alamat pasien tidak boleh kosong.');
            }
            $this->alamat = $alamat;
        }

        if ($noTelepon !== null) {
            if ($noTelepon <= 0) {
                throw new InvalidArgumentException('Nomor telepon harus berupa bilangan positif.');
            }
            $this->noTelepon = $noTelepon;
        }
    }

    /**
     * Pasien menjalani pemeriksaan dengan dokter.
     * Pembuatan catatan dilakukan oleh Dokter, lalu disimpan sebagai riwayat pasien.
     */
    public function melakukanPemeriksaan(
        Dokter $dokter,
        int $idPemeriksaan,
        DateTimeImmutable $tanggalPemeriksaan,
        string $keluhan
    ): Pemeriksaan {
        if (isset($this->riwayatPemeriksaan[$idPemeriksaan])) {
            throw new InvalidArgumentException('ID pemeriksaan sudah tercatat pada riwayat pasien ini.');
        }

        $pemeriksaan = $dokter->memeriksaPasien(
            $this,
            $idPemeriksaan,
            $tanggalPemeriksaan,
            $keluhan
        );

        $this->riwayatPemeriksaan[$pemeriksaan->getIdPemeriksaan()] = $pemeriksaan;

        return $pemeriksaan;
    }

    /** Mengembalikan seluruh catatan pemeriksaan milik pasien ini. */
    public function lihatRiwayatPemeriksaan(): array
    {
        return array_values($this->riwayatPemeriksaan);
    }

    // Getter digunakan untuk membaca atribut private secara terkendali.
    public function getIdPasien(): int
    {
        return $this->idPasien;
    }

    public function getNama(): string
    {
        return $this->nama;
    }

    public function getAlamat(): string
    {
        return $this->alamat;
    }

    public function getNoTelepon(): int
    {
        return $this->noTelepon;
    }

    private function validasiData(): void
    {
        if ($this->idPasien <= 0) {
            throw new InvalidArgumentException('ID pasien harus lebih besar dari nol.');
        }
        if (trim($this->nama) === '') {
            throw new InvalidArgumentException('Nama pasien wajib diisi.');
        }
        if (trim($this->alamat) === '') {
            throw new InvalidArgumentException('Alamat pasien wajib diisi.');
        }
        if ($this->noTelepon <= 0) {
            throw new InvalidArgumentException('Nomor telepon pasien harus lebih besar dari nol.');
        }

        $this->nama = trim($this->nama);
        $this->alamat = trim($this->alamat);
    }
}
