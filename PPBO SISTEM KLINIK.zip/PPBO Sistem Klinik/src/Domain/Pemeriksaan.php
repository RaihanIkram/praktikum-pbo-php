<?php

declare(strict_types=1);

namespace Klinik\Domain;

use DateTimeImmutable;
use InvalidArgumentException;
use Klinik\Contracts\IdentitasDokterInterface;
use Klinik\Contracts\IdentitasPasienInterface;

/**
 * Class Pemeriksaan menyimpan satu kejadian pemeriksaan.
 * Pembuatan menggunakan kontrak identitas agar tidak bergantung langsung
 * pada class Pasien atau Dokter (Dependency Inversion Principle).
 */
class Pemeriksaan
{
    private string $keluhan;
    private string $hasilPemeriksaan = 'Belum dicatat';

    private function __construct(
        private int $idPemeriksaan,
        private int $idDokter,
        private int $idPasien,
        private DateTimeImmutable $tanggalPemeriksaan,
        string $keluhan
    ) {
        if ($this->idPemeriksaan <= 0 || $this->idDokter <= 0 || $this->idPasien <= 0) {
            throw new InvalidArgumentException('ID pemeriksaan, dokter, dan pasien harus lebih besar dari nol.');
        }

        $this->catatKeluhan($keluhan);
    }

    /**
     * Factory method sesuai operasi buatPemeriksaan pada diagram.
     * Tipe interface memungkinkan objek lain yang memenuhi kontrak digunakan.
     */
    public static function buatPemeriksaan(
        int $idPemeriksaan,
        IdentitasDokterInterface $dokter,
        IdentitasPasienInterface $pasien,
        DateTimeImmutable $tanggalPemeriksaan,
        string $keluhan
    ): self {
        return new self(
            $idPemeriksaan,
            $dokter->getIdDokter(),
            $pasien->getIdPasien(),
            $tanggalPemeriksaan,
            $keluhan
        );
    }

    public function catatKeluhan(string $keluhan): void
    {
        $keluhan = trim($keluhan);
        if ($keluhan === '') {
            throw new InvalidArgumentException('Keluhan pemeriksaan wajib diisi.');
        }

        $this->keluhan = $keluhan;
    }

    public function catatHasil(string $hasil): void
    {
        $hasil = trim($hasil);
        if ($hasil === '') {
            throw new InvalidArgumentException('Hasil pemeriksaan wajib diisi.');
        }

        $this->hasilPemeriksaan = $hasil;
    }

    /** Menampilkan seluruh informasi satu catatan pemeriksaan. */
    public function tampilkanDetail(): string
    {
        return implode(PHP_EOL, [
            '----------------------------------------',
            'DETAIL PEMERIKSAAN',
            '----------------------------------------',
            'ID Pemeriksaan : ' . $this->idPemeriksaan,
            'ID Pasien      : ' . $this->idPasien,
            'ID Dokter      : ' . $this->idDokter,
            'Tanggal        : ' . $this->tanggalPemeriksaan->format('Y-m-d'),
            'Keluhan        : ' . $this->keluhan,
            'Hasil          : ' . $this->hasilPemeriksaan,
        ]);
    }

    // Getter merupakan operasi pendukung untuk akses terkontrol dan relasi.
    public function getIdPemeriksaan(): int
    {
        return $this->idPemeriksaan;
    }

    public function getIdDokter(): int
    {
        return $this->idDokter;
    }

    public function getIdPasien(): int
    {
        return $this->idPasien;
    }

    public function getTanggalPemeriksaan(): DateTimeImmutable
    {
        return $this->tanggalPemeriksaan;
    }

    public function getKeluhan(): string
    {
        return $this->keluhan;
    }

    public function getHasilPemeriksaan(): string
    {
        return $this->hasilPemeriksaan;
    }
}
