<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/autoload.php';

use Klinik\Contracts\IdentitasDokterInterface;
use Klinik\Contracts\IdentitasPasienInterface;
use Klinik\Domain\Dokter;
use Klinik\Domain\Pasien;
use Klinik\Domain\Pemeriksaan;

$passed = 0;
$failed = 0;

function assertTrue(bool $condition, string $message): void
{
    global $passed, $failed;
    if (!$condition) {
        $failed++;
        echo "[GAGAL] {$message}" . PHP_EOL;
        return;
    }

    $passed++;
    echo "[LULUS] {$message}" . PHP_EOL;
}

function assertThrows(callable $callback, string $message, string $exceptionClass = InvalidArgumentException::class): void
{
    try {
        $callback();
    } catch (Throwable $exception) {
        assertTrue($exception instanceof $exceptionClass, $message . ' (jenis exception sesuai)');
        return;
    }

    assertTrue(false, $message . ' (exception seharusnya terjadi)');
}

$pasien = new Pasien(1001, 'Andi Saputra', 'Pontianak', 6281234567890);
$dokter = new Dokter(201, 'dr. Maya Putri', 'Dokter Umum');

// 1. Proses pendaftaran pasien.
assertTrue(str_contains($pasien->mendaftar(), 'berhasil didaftarkan'), 'Method mendaftar() memberikan konfirmasi pendaftaran.');

// 2. Perubahan data pasien melalui method publik.
$pasien->ubahDataPasien(nama: 'Andi S.', alamat: 'Sungai Jawi, Pontianak', noTelepon: 628111222333);
assertTrue($pasien->getNama() === 'Andi S.' && $pasien->getAlamat() === 'Sungai Jawi, Pontianak', 'ubahDataPasien() memperbarui data pasien.');
assertTrue($pasien->getNoTelepon() === 628111222333, 'ubahDataPasien() memperbarui nomor telepon bertipe int.');

// 3. Pembuatan dua pemeriksaan untuk satu pasien dan dokter.
$pemeriksaan1 = $pasien->melakukanPemeriksaan(
    $dokter,
    5001,
    new DateTimeImmutable('2026-10-30'),
    'Demam dan sakit kepala'
);
$pemeriksaan2 = $pasien->melakukanPemeriksaan(
    $dokter,
    5002,
    new DateTimeImmutable('2026-10-31'),
    'Kontrol lanjutan'
);
assertTrue(count($pasien->lihatRiwayatPemeriksaan()) === 2, 'Multiplicity Pasien 1 ke 0..* Pemeriksaan berjalan.');
assertTrue(count($dokter->getPemeriksaanDitangani()) === 2, 'Satu Dokter dapat menangani beberapa Pemeriksaan.');
assertTrue($pemeriksaan1->getIdPasien() === 1001 && $pemeriksaan1->getIdDokter() === 201, 'Pemeriksaan menyimpan ID pasien dan dokter yang benar.');
assertThrows(
    static fn () => $pasien->melakukanPemeriksaan($dokter, 5001, new DateTimeImmutable('2026-11-01'), 'ID duplikat'),
    'ID pemeriksaan duplikat ditolak.'
);

// 4. Dokter mengisi hasil pada pemeriksaan yang ditanganinya.
$dokter->isiHasilPemeriksaan($pemeriksaan1, 'Disarankan beristirahat dan menjaga asupan cairan.');
assertTrue(
    $pemeriksaan1->getHasilPemeriksaan() === 'Disarankan beristirahat dan menjaga asupan cairan.',
    'isiHasilPemeriksaan() mencatat hasil pada objek Pemeriksaan.'
);

// 5. Dokter tidak boleh mengubah hasil pemeriksaan milik dokter lain.
$dokterLain = new Dokter(202, 'dr. Budi', 'Dokter Anak');
assertThrows(
    static fn () => $dokterLain->isiHasilPemeriksaan($pemeriksaan1, 'Hasil yang tidak berwenang'),
    'Validasi mencegah dokter lain mengisi hasil pemeriksaan.',
    DomainException::class
);

// 6. Method catatKeluhan dan catatHasil melakukan validasi.
$pemeriksaan2->catatKeluhan('Batuk ringan');
$pemeriksaan2->catatHasil('Kondisi stabil.');
assertTrue($pemeriksaan2->getKeluhan() === 'Batuk ringan', 'catatKeluhan() dapat memperbarui keluhan.');
assertTrue($pemeriksaan2->getHasilPemeriksaan() === 'Kondisi stabil.', 'catatHasil() dapat memperbarui hasil.');
assertThrows(static fn () => $pemeriksaan2->catatKeluhan('   '), 'catatKeluhan() menolak keluhan kosong.');
assertThrows(static fn () => $pemeriksaan2->catatHasil('   '), 'catatHasil() menolak hasil kosong.');

// 7. Perubahan spesialisasi dokter.
$dokter->ubahSpesialisasi('Dokter Penyakit Dalam');
assertTrue($dokter->getSpesialisasi() === 'Dokter Penyakit Dalam', 'ubahSpesialisasi() memperbarui spesialisasi dokter.');

// 8. Validasi konstruktor pasien dan dokter.
assertThrows(static fn () => new Pasien(0, 'Nama', 'Alamat', 6281234567890), 'Pasien menolak ID yang tidak valid.');
assertThrows(static fn () => new Dokter(0, 'Nama Dokter', 'Umum'), 'Dokter menolak ID yang tidak valid.');

// 9. DIP/OCP/LSP: Pemeriksaan dapat menggunakan objek alternatif yang memenuhi interface.
$pasienAlternatif = new class implements IdentitasPasienInterface {
    public function getIdPasien(): int { return 9001; }
};
$dokterAlternatif = new class implements IdentitasDokterInterface {
    public function getIdDokter(): int { return 9201; }
};

$pemeriksaanAlternatif = Pemeriksaan::buatPemeriksaan(
    9501,
    $dokterAlternatif,
    $pasienAlternatif,
    new DateTimeImmutable('2026-10-31'),
    'Pemeriksaan melalui implementasi interface alternatif'
);
assertTrue($pemeriksaanAlternatif->getIdPasien() === 9001, 'Pemeriksaan menerima implementasi alternatif IdentitasPasienInterface (OCP/LSP).');
assertTrue($pemeriksaanAlternatif->getIdDokter() === 9201, 'Pemeriksaan menerima implementasi alternatif IdentitasDokterInterface (DIP/LSP).');

// 10. Method tampilkanDetail menghasilkan informasi yang lengkap.
$detail = $pemeriksaan1->tampilkanDetail();
assertTrue(
    str_contains($detail, 'ID Pemeriksaan : 5001')
    && str_contains($detail, 'ID Pasien      : 1001')
    && str_contains($detail, 'ID Dokter      : 201')
    && str_contains($detail, 'Demam dan sakit kepala'),
    'tampilkanDetail() menampilkan identitas dan informasi pemeriksaan.'
);

// 11. Validasi nomor telepon mengikuti tipe int pada diagram.
assertThrows(static fn () => $pasien->ubahDataPasien(noTelepon: -1), 'Nomor telepon negatif ditolak.');
assertThrows(static fn () => $pasien->ubahDataPasien(), 'Perubahan tanpa data baru ditolak.');

printf("\nRingkasan pengujian: %d lulus, %d gagal.\n", $passed, $failed);
exit($failed === 0 ? 0 : 1);
