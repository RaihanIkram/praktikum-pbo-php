

<?php

class Product
{
    public $nama;
    public $harga;
    public $kategori;

    public function __construct($nama, $harga, $kategori)
    {
        $this->nama = $nama;
        $this->harga = $harga;
        $this->kategori = $kategori;
    }

    public function getInfo()
    {
        return "Nama: $this->nama<br>" .
               "Harga: Rp " . number_format($this->harga, 0, ',', '.') . "<br>" .
               "Kategori: $this->kategori<br>";
    }

    public function applyDiskon($persen)
    {
        $this->harga = $this->harga - ($this->harga * $persen / 100);
    }
}

$product1 = new Product("Laptop Asus", 12000000, "Elektronik");
$product2 = new Product("Mouse Logitech", 300000, "Aksesoris");

echo "Product 1<br>";
echo $product1->getInfo();
$product1->applyDiskon(10);
echo "Setelah diskon 10%:<br>";
echo $product1->getInfo();

echo "<br>";

echo "Product 2<br>";
echo $product2->getInfo();
$product2->applyDiskon(20);
echo "Setelah diskon 20%:<br>";
echo $product2->getInfo();

?>