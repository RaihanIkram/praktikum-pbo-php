<?php

require_once '../Catatan.php';

$c = new Catatan();

$hasil = $c->setJudul("Catatan Kuliah")
    ->setIsi("Mempelajari PHP dan MySQL")
    ->save();

echo $hasil ? "Berhasil disimpan" : "Gagal";