
<?php
// Parent Class
class Produk
{
    protected $merek;
    protected $harga;

    // Constructor
    public function __construct($merek, $harga)
    {
        if ($harga < 0) {
            $harga = 0;
        }

        $this->merek = $merek;
        $this->harga = $harga;
    }

    // Method getInfo
    public function getInfo()
    {
        return "Merek: " . $this->merek .
               "<br>Harga: Rp " . $this->harga;
    }
}
// Child Class Makanan
class Makanan extends Produk
{
    private $tanggalKadaluarsa;

    public function __construct($merek, $harga, $tanggalKadaluarsa)
    {
        parent::__construct($merek, $harga);
        $this->tanggalKadaluarsa = $tanggalKadaluarsa;
    }
    // Override getInfo
    public function getInfo()
    {
        return "Produk: Makanan - Mie Instan<br>" .
               parent::getInfo() . "<br>" .
               "Tanggal Kadaluarsa: " . $this->tanggalKadaluarsa . "<br>" .
               "Status: Segar";
    }
}


// Child Class Elektronik
class Elektronik extends Produk
{
    private $garansi;

    public function __construct($merek, $harga, $garansi)
    {
        parent::__construct($merek, $harga);
        $this->garansi = $garansi;
    }

    // Override getInfo
    public function getInfo()
    {
        return "Produk: Elektronik - Smart TV<br>" .
               parent::getInfo() . "<br>" .
               "Garansi: " . $this->garansi . " bulan";
    }
}


// Membuat object
$makanan = new Makanan("Indomie", 3500, "2029-06-30");
$elektronik = new Elektronik("Samsung", 5000000, 12);


// Menampilkan informasi
echo $makanan->getInfo();

echo "<br><br>";

echo $elektronik->getInfo();

?>


