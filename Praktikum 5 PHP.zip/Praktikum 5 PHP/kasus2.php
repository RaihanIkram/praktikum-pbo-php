

<?php
// Contoh inheritance
class Produk
{
    public $nama;
    public $harga;
    public $stok;

    public function __construct($nama, $harga, $stok)
    {
        $this->nama = $nama;
        $this->harga = $harga;
        $this->stok = $stok;
    }

    public function tampilkanProduk()
    {
        echo "Produk: " . $this->nama . "<br>";
        echo "Harga: " . $this->harga . "<br>";
        echo "Stok: " . $this->stok . "<br>";
    }
}

class Makanan extends Produk
{
}

$makanan = new Makanan("Makanan", 10000, 10);
$makanan->tampilkanProduk();


// Contoh trait
trait Logger
{
    public function log($pesan)
    {
        echo $pesan;
    }
}

class Karyawan
{
    use Logger;
}

class Pelanggan
{
    use Logger;
}

$karyawan = new Karyawan();
$pelanggan = new Pelanggan();

$karyawan->log("Karyawan melakukan aktivitas");
echo "<br>";
$pelanggan->log("Pelanggan melakukan aktivitas");

?>