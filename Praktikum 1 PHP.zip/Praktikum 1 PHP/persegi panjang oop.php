


<?php

class PersegiPanjang
{
    public $panjang;
    public $lebar;

    public function luas()
    {
        return $this->panjang * $this->lebar;
    }
}

$persegiPanjang = new PersegiPanjang();

$persegiPanjang->panjang = 10;
$persegiPanjang->lebar = 5;

echo "Luas persegi panjang = " . $persegiPanjang->luas();

?>