<?php
class Mobil
{
    public $merk;
    public $warna;

    public function infoMobil()
    {
        return "Mobil " . $this->merk . " berwarna " . $this->warna;
    }
}
$mobil = new Mobil();
$mobil->merk = "Toyota";
$mobil->warna = "Merah";

echo $mobil->infoMobil();
?>